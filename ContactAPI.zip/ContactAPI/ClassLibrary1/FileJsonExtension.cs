﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Test.Model.Data;

namespace Test.ServerAP.Manager
{
   public static class FileJsonExtension 
   {
      public static void JsonToFile(this List<Contact> contacts)
      {        
         var applicationPath = AppContext.BaseDirectory;
         string filePath = Path.Combine(applicationPath, "Contact.Json");
         File.Create(filePath).Close();
         using (StreamWriter file = File.CreateText(filePath))
         {
            // serialize the JSON to file.
            JsonSerializer serializer = new JsonSerializer();
            serializer.Serialize(file, contacts);
         }
      }

      public static List<Contact> FileToJson(this List<Contact> contacts)
      {         
         var applicationPath = AppContext.BaseDirectory;
         string serializationFile = Path.Combine(applicationPath, "Contact.Json");

         // de-serialize JSON directly from a file.
         if(File.Exists(@serializationFile))          
         using (StreamReader file = File.OpenText(@serializationFile))
         {
            JsonSerializer serializer = new JsonSerializer();              
            contacts = (List<Contact>)serializer.Deserialize(file, typeof(List<Contact>));           
         }
         return contacts;
      }
   }
}
