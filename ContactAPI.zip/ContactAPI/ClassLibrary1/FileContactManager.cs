﻿using Newtonsoft.Json;
using Newtonsoft.Json.Bson;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.Json;
using Test.Model.Data;
using Test.Model.Interface;
using System.Linq;
using JsonSerializer = Newtonsoft.Json.JsonSerializer;
using Test.Model.Enums;

namespace Test.ServerAP.Manager
{
   public class FileContactManager : IContactOperations
   {
      private List<Contact> _contactList = new List<Contact>();
      public bool AddContact(Contact contact)
      {
         bool isContactAdded = false;
         try
         {
            if (contact != null)
            {
               var contactList = _contactList.FileToJson();
               if (contactList != null && contactList.Count > 0)
               {
                  bool isContactExist = contactList.Where(c => c != null && (c.Email.Equals(contact.Email, StringComparison.OrdinalIgnoreCase)
                                         || c.Phone.Equals(contact.Phone, StringComparison.OrdinalIgnoreCase))).Any<Contact>();
                  if (isContactExist)
                  {
                     throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Email address or phone number already exist.");
                  }
                  _contactList = contactList;
               }
               _contactList.Add(contact);
               _contactList.JsonToFile();
               isContactAdded = true;

            }
            else
            {
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Please provide contact details.");
            }
         }
         catch (ServerException serverException)
         {
            throw serverException;
         }
         catch (Exception exception)
         {
            throw new ServerException(System.Net.HttpStatusCode.InternalServerError, exception.Message);
         }
         return isContactAdded;
      }

      public List<Contact> GetContactList()
      {
         try
         {
            _contactList = _contactList.FileToJson();
            if (_contactList != null)
            {
               return _contactList;
            }
            else
            {
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Contact list is empty.");
            }
         }
         catch (ServerException serverException)
         {
            throw serverException;
         }
         catch (Exception exception)
         {
            throw new ServerException(System.Net.HttpStatusCode.InternalServerError, exception.Message);
         }
      }

      public bool EditContact(string id, Contact contact)
      {
         bool isContactAdded = false;
         try
         {
            if (!string.IsNullOrWhiteSpace(id))
            {
               var contactList = _contactList.FileToJson();
               if (contactList != null && contactList.Count > 0)
               {
                  _contactList = contactList;
                  Contact getContact = _contactList.Where(c => c != null && c.Id.Equals(id.Trim(), StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                  if (getContact == null)
                  {
                     throw new ServerException(System.Net.HttpStatusCode.NotFound, "No contact found for the given contact id :. " + id);
                  }

                  bool isPhoneOrEmailUsed = _contactList.Where(c => c != null && c.Phone.Equals(contact.Phone, StringComparison.OrdinalIgnoreCase) || c.Email.Equals(contact.Email, StringComparison.OrdinalIgnoreCase)).Any<Contact>();
                  if (isPhoneOrEmailUsed)
                  {
                     throw new ServerException(System.Net.HttpStatusCode.NotFound, "The provided Email or Phone number already in use.");
                  }
                  _contactList.Remove(getContact);
                  getContact.FirstName = contact.FirstName;
                  getContact.LastName = contact.LastName;
                  getContact.Phone = contact.Phone;
                  _contactList.Add(getContact);
                  _contactList.JsonToFile();
                  isContactAdded = true;
               }
               else
               {
                  throw new ServerException(System.Net.HttpStatusCode.NotFound, "There is no contacts present.Please add one and try again.");
               }
            }
            else
            {
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Provided contact id is null or empty.");
            }
         }
         catch (ServerException serverException)
         {
            throw serverException;
         }
         catch (Exception exception)
         {
            throw new ServerException(System.Net.HttpStatusCode.InternalServerError, exception.Message);
         }
         return isContactAdded;
      }

      public bool DeleteContact(string id)
      {
         bool isContactDeleted = false;
         try
         {
            if (!string.IsNullOrWhiteSpace(id))
            {
               var contactList = _contactList.FileToJson();
               if (contactList != null && contactList.Count > 0)
               {
                  ;
                  _contactList = contactList;
                  Contact getContact = _contactList.Where(c => c != null && c.Id.Equals(id.Trim(), StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                  if (getContact == null)
                  {
                     throw new ServerException(System.Net.HttpStatusCode.NotFound, "No contact found for the given contact id :. " + id);
                  }
                  _contactList.Remove(getContact);
                  _contactList.JsonToFile();
                  isContactDeleted = true;
               }
               else
               {
                  throw new ServerException(System.Net.HttpStatusCode.NotFound, "There is no contacts present.Please add one and try again.");
               }
            }
            else
            {
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Provided contact id is null or empty.");
            }
         }
         catch (ServerException serverException)
         {
            throw serverException;
         }
         catch (Exception exception)
         {
            throw new ServerException(System.Net.HttpStatusCode.InternalServerError, exception.Message);
         }
         return isContactDeleted;
      }


      public bool InactiveContact(string id)
      {
         bool isContactDeleted = false;
         try
         {
            if (!string.IsNullOrWhiteSpace(id))
            {
               var contactList = _contactList.FileToJson();
               if (contactList != null && contactList.Count > 0)
               {                  
                  _contactList = contactList;
                  Contact getContact = _contactList.Where(c => c != null && c.Id.Equals(id.Trim(), StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                  if (getContact == null)
                  {
                     throw new ServerException(System.Net.HttpStatusCode.NotFound, "No contact found for the given contact id :. " + id);
                  }
                  _contactList.Remove(getContact);
                  getContact.Status =(ContactStatus.Inactive).ToString();
                  _contactList.Add(getContact);
                  _contactList.JsonToFile();
                  isContactDeleted = true;
               }
               else
               {
                  throw new ServerException(System.Net.HttpStatusCode.NotFound, "There is no contacts present.Please add one and try again.");
               }
            }
            else
            {
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Provided contact id is null or empty.");
            }
         }
         catch (ServerException serverException)
         {
            throw serverException;
         }
         catch (Exception exception)
         {
            throw new ServerException(System.Net.HttpStatusCode.InternalServerError, exception.Message);
         }
         return isContactDeleted;
      }


   }
}
