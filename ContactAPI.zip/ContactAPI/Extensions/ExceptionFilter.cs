﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Test.Model.Enums;
using Test.Model.Model;

namespace ContactServices.Extensions
{
   internal class ExceptionFilter : IExceptionFilter
   {
      private readonly IHostingEnvironment _hostingEnvironment;
      //private readonly ILogger _logger;

      public ExceptionFilter(IHostingEnvironment hostingEnvironment)
      {
         _hostingEnvironment = hostingEnvironment;
         //_logger = logger;
      }

      public void OnException(ExceptionContext context)
      {
         //_logger.Error(context.Exception);

         //if (_hostingEnvironment.IsDevelopment())
         //{
         //   // Do not modify context.Result in development mode so developer exception page is shown
         //   return;
         //}

         HttpResponse response = context.HttpContext.Response;
         Exception exception = context.Exception;
         ApiError apiError = new ApiError();
         switch (exception)
         {
            case UnauthorizedAccessException _:
               response.StatusCode = (int)HttpStatusCode.Forbidden;
               apiError.Message = "Access was not authorized."; 
               apiError.Code = (ApiErrorType.Unauthorized).ToString();
               break;
            case ArgumentException _:
               response.StatusCode = (int)HttpStatusCode.BadRequest;
               apiError.Message = exception.Message;
               apiError.Code = (ApiErrorType.InvalidParameter).ToString();
               break;
            case NotImplementedException _:
               response.StatusCode = (int)HttpStatusCode.NotImplemented;
               apiError.Message = "The requested operation is not implemented."; 
               apiError.Code = (ApiErrorType.NotImplemented).ToString();
               break;
            default:
               response.StatusCode = (int)HttpStatusCode.InternalServerError;
               apiError.Message = exception.Message;
               apiError.Code = (ApiErrorType.InternalServerError).ToString();
               apiError.Details = new List<ApiError>();
               apiError.Details.Add(new ApiError() { Message = exception.ToString(), Code = "" });
               break;
         }       
         context.Result = new JsonResult(apiError);
      }
   }
}
