﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using Test.Model.Data;
using Test.Model.Interface;
using Test.Model.Model;

namespace ContactServices.Controllers
{
   [Route("api/v1.0")]
   [ApiController]
   public class ContactController : ControllerBase
   {
      private readonly IContactOperations _contactFileManager;
      public ContactController(IContactOperations contactDetails)
      {
         _contactFileManager = contactDetails;
      }

      [Route("GetContactList")]
      [HttpGet]
      public IActionResult GetContactList()
      {
         try
         {
            var contacts = _contactFileManager.GetContactList();
            return Ok(contacts);
         }
         catch (ServerException serverException)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(serverException, "ContactList");
            return StatusCode(Convert.ToInt32(serverException.HttpStatusCode), apiError);
         }
         catch (Exception exception)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(exception, "ContactList");
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), apiError);
         }

      }


      [Route("AddContact")]
      [HttpPost]
      public IActionResult PostAddContact([FromBody] Contact contact)
      {
         try
         {
            if (ModelState.IsValid)
            {
               string guid = Guid.NewGuid().ToString();
               contact.Id = guid;
               bool isContactAdded = _contactFileManager.AddContact(contact);
               if (isContactAdded)
               {
                  return Ok();
               }
            }
            else
               throw new ServerException(HttpStatusCode.BadRequest, "Invalid contact data or missing data.");
         }
         catch (ServerException serverException)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(serverException, "AddContact");
            return StatusCode(Convert.ToInt32(serverException.HttpStatusCode), apiError);
         }
         catch (Exception exception)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(exception, "AddContact");
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), apiError);
         }
         return Ok();
      }


      [Route("EditContact/{id}")]
      [HttpPut]
      public IActionResult PutEditContact([FromRoute][Required] string id, [Required][FromBody] Contact contact)
      {
         try
         {
            if (ModelState.IsValid)
            {
               bool isContactAdded = _contactFileManager.EditContact(id, contact);
               if (isContactAdded)
               {
                  return Ok();
               }
            }
         }
         catch (ServerException serverException)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(serverException, "EditContact");
            return StatusCode(Convert.ToInt32(serverException.HttpStatusCode), apiError);
         }
         catch (Exception exception)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(exception, "EditContact");
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), apiError);
         }
         return Ok();
      }


      [Route("DeleteContact/{id}")]
      [HttpDelete]
      public IActionResult DeleteRemoveContact([FromRoute][Required] string id)
      {
         try
         {
            bool isContactAdded = _contactFileManager.DeleteContact(id);
            if (isContactAdded)
            {
               return Ok();
            }
         }
         catch (ServerException serverException)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(serverException, "RemoveContact");
            return StatusCode(Convert.ToInt32(serverException.HttpStatusCode), apiError);
         }
         catch (Exception exception)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(exception, "RemoveContact");
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), apiError);
         }
         return Ok();
      }

      [Route("InactiveContact/{id}")]
      [HttpPut]
      public IActionResult InactiveContact([FromRoute][Required] string id)
      {
         try
         {
            bool isContactAdded = _contactFileManager.InactiveContact(id);
            if (isContactAdded)
            {
               return Ok();
            }
         }
         catch (ServerException serverException)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(serverException, "InactiveContact");
            return StatusCode(Convert.ToInt32(serverException.HttpStatusCode), apiError);
         }
         catch (Exception exception)
         {
            ApiError apiError = ApiErrorUtility.GetAPIErrorException(exception, "InactiveContact");
            return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError), apiError);
         }
         return Ok();
      }

   }
}
