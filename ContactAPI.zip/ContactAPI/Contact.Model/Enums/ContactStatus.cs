﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test.Model.Enums
{
	[Flags]
	public enum ContactStatus
	{
		Active,
		Inactive,
	}
}
