﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test.Model.Enums
{
	[Flags]
	public enum ApiErrorType
	{
		Undefined,

		NotFound,

		Unauthorized,

		NotImplemented,

		Forbidden,

		InternalServerError,

		InvalidParameter,
	}
}
