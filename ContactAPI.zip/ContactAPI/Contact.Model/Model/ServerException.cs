﻿using System;
using System.Net;
/// <summary>
/// Custom Exception class, this type of exception would be thrown from backend/business logic,
/// controller would use this to prepare exception response
/// </summary>
public class ServerException : Exception
{
   public HttpStatusCode HttpStatusCode { get; set; }
   public string ExceptionMessage { get; set; }
   public Exception OriginalException { get; set; }

   public string SubStatusCode { get; set; }
   public ServerException(HttpStatusCode httpStatusCode, string exceptionMessage, Exception originalException = null)
   {
      HttpStatusCode = httpStatusCode;
      ExceptionMessage = exceptionMessage;
      OriginalException = originalException;     
   }

}