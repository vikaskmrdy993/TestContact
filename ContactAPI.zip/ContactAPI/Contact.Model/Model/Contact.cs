﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;
using System.ComponentModel.DataAnnotations;
using Test.Model.Enums;

namespace Test.Model.Data
{
   [DataContract]
   public class Contact
   {
      private string _status = (ContactStatus.Active).ToString();
      [DataMember(Name = "id")]
      public string Id { get; set; }
      [Required]
      [DataMember(Name = "firstName")]
      public string FirstName { get; set; }
      [Required]
      [DataMember(Name = "lastName")]
      public string LastName { get; set; }
      [Required, EmailAddress]
      [DataMember(Name = "email")]
      [DataType(DataType.EmailAddress)]
      public string Email { get; set; }
      [Required, Phone]
      [DataType(DataType.PhoneNumber)]
      [DataMember(Name = "phone")]
      public string Phone { get; set; }

      [DataMember(Name = "status")]
      public string Status
      {
         get
         {
            return _status;
         }
         set
         {
            _status = value;
         }
      }
   }
}
