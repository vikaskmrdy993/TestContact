﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace Test.Model.Model
{
	public class ApiError
	{
		/// <summary>
		/// Error Code
		/// </summary>

		[Required]
		[DataMember(Name = "code")]
		public string Code { get; set; }
		/// <summary>
		/// Error message
		/// </summary>
		[Required]
		[DataMember(Name = "message")]
		public string Message { get; set; }

		/// <summary>
		/// The value is the target of the particular error (e.g., the name of the property in error)
		/// </summary>
		/// <value>The value is the target of the particular error (e.g., the name of the property in error)</value>
		[DataMember(Name = "target")]
		public string Target { get; set; }

		/// <summary>
		/// An array of details about specific errors that led to this reported error
		/// </summary>
		/// <value>An array of details about specific errors that led to this reported error</value>
		[DataMember(Name = "details")]
		public List<ApiError> Details { get; set; }

	}
}
