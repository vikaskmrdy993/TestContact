﻿using System;
using System.Collections.Generic;
using System.Text;
using Test.Model.Enums;

namespace Test.Model.Model
{
   public static class ApiErrorUtility
   {
      /// <summary>
      ///  Returns ApiError object that can be used to send as a response to the caller for ECMServerException occurred.
      /// </summary>
      /// <param name="ecmServerException"></param>
      /// <param name="target"></param>
      /// <returns></returns>
      public static ApiError GetAPIErrorException(ServerException ecmServerException, string target = "")
      {
         ApiError apiError = new ApiError();
         apiError.Code = string.IsNullOrEmpty(ecmServerException.SubStatusCode) ? ecmServerException.HttpStatusCode.ToString() : ecmServerException.SubStatusCode;
         apiError.Message = ecmServerException.ExceptionMessage;
         apiError.Target = target;
         if (ecmServerException.OriginalException != null)
         {
            apiError.Details = new List<ApiError>();
            apiError.Details.Add(new ApiError() { Message = ecmServerException.OriginalException.ToString(), Code = "" });
         }        
         return apiError;
      }

      /// <summary>
      /// Returns ApiError object that can be used to send as a response to the caller for generic exception occurred.
      /// </summary>
      /// <param name="exception"></param>
      /// <param name="target"></param>
      /// <returns></returns>
      public static ApiError GetAPIErrorException(Exception exception, string target = "")
      {
         ApiError apiError = new ApiError();
         apiError.Message = exception.Message;
         apiError.Code = (ApiErrorType.InternalServerError).ToString();
         apiError.Target = target;
         apiError.Details = new List<ApiError>();
         apiError.Details.Add(new ApiError() { Message = exception.ToString(), Code = "" });       
         return apiError;
      }
   }
}
