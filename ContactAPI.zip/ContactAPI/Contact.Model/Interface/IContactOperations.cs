﻿using System;
using System.Collections.Generic;
using System.Text;
using Test.Model.Data;

namespace Test.Model.Interface
{
  public interface IContactOperations
   {
      public bool AddContact(Contact contact);
      public List<Contact> GetContactList();
      public bool EditContact(string id, Contact contact);
      public bool DeleteContact(string id);
      public bool InactiveContact(string id);
   }
}
