using ContactServices.Controllers;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using Test.Model.Data;
using Test.Model.Interface;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System;

namespace NUnitTestProject1
{
   [TestFixture]
   public class ContactControllerTest
   {
      private Mock<IContactOperations> _fileContactManager;
      private ContactController _contactController;
      List<Contact> _contactList = new List<Contact>();

      [SetUp]
      public void Setup()
      {
         _fileContactManager = new Mock<IContactOperations>();
         _contactController = new ContactController(_fileContactManager.Object);
         _contactList.Add(new Contact() { FirstName = "Test", LastName = "TestData", Email = "test@test.com", Phone = "1000000000" });
      }

      [Test]
      public void TestGetContactList()
      {

         _fileContactManager.Setup(m => m.GetContactList()).Returns(_contactList);
         IActionResult actionResult = _contactController.GetContactList();
         Assert.IsInstanceOf(typeof(OkObjectResult), actionResult);
      }

      [TestCase("Exception")]
      [TestCase("ServerException")]
      public void TestGetContactList_Exception(string exceptionType)
      {
         _fileContactManager.Setup(m => m.GetContactList()).Callback(() =>
         {
            if (exceptionType.Equals("Exception"))
               throw new Exception("Test Exception");
            else
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Test Exception");
         }).Returns(_contactList);
         IActionResult actionResult = _contactController.GetContactList();
         Assert.IsInstanceOf(typeof(ObjectResult), actionResult);
         ObjectResult result = actionResult as ObjectResult;
         if (exceptionType.Equals("Exception"))
            Assert.AreEqual(500, result.StatusCode);
         else
            Assert.AreEqual(400, result.StatusCode);
      }


      [Test]
      public void TestAddContact()
      {
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.AddContact(It.IsAny<Contact>())).Returns(true);
         IActionResult actionResult = _contactController.PostAddContact(contact);
         Assert.IsInstanceOf(typeof(OkResult), actionResult);
      }

      [TestCase("Exception")]
      [TestCase("ServerException")]
      public void TestAddContact_Exception(string exceptionType)
      {
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.AddContact(It.IsAny<Contact>())).Callback(() =>
         {
            if (exceptionType.Equals("Exception"))
               throw new Exception("Test Exception");
            else
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Test Exception");
         }).Returns(true);
         IActionResult actionResult = _contactController.PostAddContact(contact);
         Assert.IsInstanceOf(typeof(ObjectResult), actionResult);
         ObjectResult result = actionResult as ObjectResult;
         if (exceptionType.Equals("Exception"))
            Assert.AreEqual(500, result.StatusCode);
         else
            Assert.AreEqual(400, result.StatusCode);
      }

      [Test]
      public void TestEditContact()
      {
         string id = Guid.NewGuid().ToString();
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.EditContact(It.IsAny<string>(), It.IsAny<Contact>())).Returns(true);
         IActionResult actionResult = _contactController.PutEditContact(id, contact);
         Assert.IsInstanceOf(typeof(OkResult), actionResult);
      }

      [TestCase("Exception")]
      [TestCase("ServerException")]
      public void TestEditContact_Exception(string exceptionType)
      {
         string id = Guid.NewGuid().ToString();
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.EditContact(It.IsAny<string>(), It.IsAny<Contact>())).Callback(() =>
         {
            if (exceptionType.Equals("Exception"))
               throw new Exception("Test Exception");
            else
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Test Exception");
         }).Returns(true);
         IActionResult actionResult = _contactController.PutEditContact(id, contact);
         Assert.IsInstanceOf(typeof(ObjectResult), actionResult);
         ObjectResult result = actionResult as ObjectResult;
         if (exceptionType.Equals("Exception"))
            Assert.AreEqual(500, result.StatusCode);
         else
            Assert.AreEqual(400, result.StatusCode);
      }


      [Test]
      public void TestDeleeContact()
      {
         string id = Guid.NewGuid().ToString();
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.DeleteContact(It.IsAny<string>())).Returns(true);
         IActionResult actionResult = _contactController.DeleteRemoveContact(id);
         Assert.IsInstanceOf(typeof(OkResult), actionResult);
      }

      [TestCase("Exception")]
      [TestCase("ServerException")]
      public void TestDeleteContact_Exception(string exceptionType)
      {
         string id = Guid.NewGuid().ToString();
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.DeleteContact(It.IsAny<string>())).Callback(() =>
         {
            if (exceptionType.Equals("Exception"))
               throw new Exception("Test Exception");
            else
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Test Exception");
         }).Returns(true);
         IActionResult actionResult = _contactController.DeleteRemoveContact(id);
         Assert.IsInstanceOf(typeof(ObjectResult), actionResult);
         ObjectResult result = actionResult as ObjectResult;
         if (exceptionType.Equals("Exception"))
            Assert.AreEqual(500, result.StatusCode);
         else
            Assert.AreEqual(400, result.StatusCode);
      }


      [Test]
      public void TestInactiveContact()
      {
         string id = Guid.NewGuid().ToString();
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.InactiveContact(It.IsAny<string>())).Returns(true);
         IActionResult actionResult = _contactController.DeleteRemoveContact(id);
         Assert.IsInstanceOf(typeof(OkResult), actionResult);
      }

      [TestCase("Exception")]
      [TestCase("ServerException")]
      public void TestInactive_Exception(string exceptionType)
      {
         string id = Guid.NewGuid().ToString();
         Contact contact = new Contact();
         _fileContactManager.Setup(m => m.InactiveContact(It.IsAny<string>())).Callback(() =>
         {
            if (exceptionType.Equals("Exception"))
               throw new Exception("Test Exception");
            else
               throw new ServerException(System.Net.HttpStatusCode.BadRequest, "Test Exception");
         }).Returns(true);
         IActionResult actionResult = _contactController.InactiveContact(id);
         Assert.IsInstanceOf(typeof(ObjectResult), actionResult);
         ObjectResult result = actionResult as ObjectResult;
         if (exceptionType.Equals("Exception"))
            Assert.AreEqual(500, result.StatusCode);
         else
            Assert.AreEqual(400, result.StatusCode);
      }
   }
}